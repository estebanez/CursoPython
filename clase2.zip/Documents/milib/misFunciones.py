def MiFuncion(cadena):
    print ("hola")

def OtraFuncion(cadena):
    print (cadena)